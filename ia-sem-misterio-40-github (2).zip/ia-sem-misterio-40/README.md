# IA Sem Mistério 40+ — Landing page

Página estática responsiva inspirada na estrutura da página Finanças 40+.

## Publicação no GitHub Pages
1. Crie um repositório no GitHub.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Em **Settings > Pages**, escolha **Deploy from a branch**, branch `main` e pasta `/ (root)`.
4. Salve e aguarde a URL do GitHub Pages.

## Antes de vender
- No final do arquivo `index.html`, preencha `CHECKOUT_COMPLETO` e `CHECKOUT_BASICO` com os links reais de compra.
- Substitua os mockups ilustrativos por fotos reais dos materiais, se disponíveis.
- Substitua os exemplos de depoimentos por avaliações autênticas autorizadas.
- Confira e documente as condições da garantia e a disponibilidade real da promoção.
- A data e o contador refletem o horário de Brasília e reiniciam diariamente; configure uma data final real se a promoção não for diária.
